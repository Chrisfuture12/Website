module.exports = require('./lib/render')
